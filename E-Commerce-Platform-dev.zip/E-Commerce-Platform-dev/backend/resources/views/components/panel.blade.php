
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 md:p-6 rounded-xl shadow-sm">

        {{ $slot }}
    </div>
