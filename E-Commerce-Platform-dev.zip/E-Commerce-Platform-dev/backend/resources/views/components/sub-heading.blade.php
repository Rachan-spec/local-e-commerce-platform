<p class="text-sm sm:text-base text-gray-500">
    {{ $slot }}
</p>
