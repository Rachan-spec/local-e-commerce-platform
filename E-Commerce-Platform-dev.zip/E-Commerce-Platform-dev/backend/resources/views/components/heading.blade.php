<h1 class="text-xl sm:text-2xl font-bold text-gray-800">
    {{ $slot }}
</h1>